package com.example.fpslab

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var params: WindowManager.LayoutParams? = null
    private val bg = 0xEE172331.toInt()
    private val blue = 0xFF4CA8E8.toInt()

    override fun onCreate() {
        super.onCreate()
        createNotification()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun createNotification() {
        val channelId = "fps_lab_demo"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "FPS Lab demo", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification: Notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setContentTitle("FPS Lab demo activo")
                .setContentText("Panel flotante de demostración")
                .setSmallIcon(android.R.drawable.ic_menu_view).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("FPS Lab demo activo")
                .setContentText("Panel flotante de demostración")
                .setSmallIcon(android.R.drawable.ic_menu_view).build()
        }
        startForeground(7, notification)
    }

    private fun lp(): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 180 }
    }

    private fun text(s: String, size: Float = 14f): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.WHITE); setPadding(10, 8, 10, 8)
    }

    private fun showPanel() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg); setPadding(10, 8, 10, 10)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(text("FPS LAB • DEMO", 15f), LinearLayout.LayoutParams(0, -2, 1f))
        val min = TextView(this).apply {
            text = "—"; textSize = 22f; setTextColor(Color.WHITE); setPadding(14, 4, 14, 4)
            setOnClickListener { minimize(outer) }
        }
        val close = TextView(this).apply {
            text = "×"; textSize = 22f; setTextColor(Color.WHITE); setPadding(12, 4, 8, 4)
            setOnClickListener { stopSelf() }
        }
        header.addView(min); header.addView(close)
        outer.addView(header)
        val divider = View(this).apply { setBackgroundColor(blue) }
        outer.addView(divider, LinearLayout.LayoutParams(-1, 2))
        outer.addView(text("Solo interfaz visual; no interactúa con el juego.", 11f))
        outer.addView(Switch(this).apply {
            text = "Aimbot (simulado)"; setTextColor(Color.WHITE); isChecked = false
        })
        outer.addView(Switch(this).apply {
            text = "Wallhack / ESP (simulado)"; setTextColor(Color.WHITE); isChecked = false
        })
        outer.addView(text("FOV de demostración"))
        outer.addView(SeekBar(this).apply { max = 160; progress = 70 })
        outer.addView(text("Suavidad de demostración"))
        outer.addView(SeekBar(this).apply { max = 100; progress = 50 })
        outer.addView(text("Arrastrá desde la barra superior para mover el panel.", 10f))
        panel = outer
        params = lp()
        attachDrag(header)
        wm.addView(outer, params)
    }

    private fun minimize(outer: LinearLayout) {
        val p = params ?: return
        val minimized = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xEE173B58.toInt()); setPadding(12, 8, 12, 8)
        }
        minimized.addView(text("FPS LAB", 13f))
        minimized.addView(TextView(this).apply {
            text = "+"; textSize = 20f; setTextColor(Color.WHITE); setPadding(14, 0, 8, 0)
            setOnClickListener {
                try { wm.removeView(minimized) } catch (_: Exception) {}
                panel = null
                showPanel()
            }
        })
        try { wm.removeView(outer) } catch (_: Exception) {}
        panel = minimized
        attachDrag(minimized)
        wm.addView(minimized, p)
    }

    private fun attachDrag(v: View) {
        v.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(view: View, e: MotionEvent): Boolean {
                val p = params ?: return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; return true }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = sx + (e.rawX - tx).toInt()
                        p.y = sy + (e.rawY - ty).toInt()
                        try { wm.updateViewLayout(panel, p) } catch (_: Exception) {}
                        return true
                    }
                }
                return false
            }
        })
    }

    override fun onDestroy() {
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
