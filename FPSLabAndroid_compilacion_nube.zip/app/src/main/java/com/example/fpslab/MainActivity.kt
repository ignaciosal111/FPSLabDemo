package com.example.fpslab

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            setBackgroundColor(0xFF10151D.toInt())
        }
        box.addView(TextView(this).apply {
            text = "FPS Lab — Panel flotante de demostración"
            textSize = 21f
            setTextColor(0xFFFFFFFF.toInt())
        })
        box.addView(TextView(this).apply {
            text = "\nEste panel solo muestra controles visuales de prueba. No modifica Counter Flame, no apunta por ti y no revela jugadores."
            textSize = 15f
            setTextColor(0xFFB8C7D9.toInt())
        })
        box.addView(Button(this).apply {
            text = "Activar panel flotante"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(i)
                } else {
                    startOverlay()
                }
            }
        })
        box.addView(Button(this).apply {
            text = "Cerrar panel flotante"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        setContentView(box)
    }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
            // Permission was granted; user can activate the panel with the button.
        }
    }

    private fun startOverlay() {
        val intent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
        Toast.makeText(this, "Panel de demostración activado", Toast.LENGTH_SHORT).show()
    }
}
